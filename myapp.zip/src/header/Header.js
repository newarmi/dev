import React from 'react';
import Inner from './Inner/Inner';
import Side from './side/Side';
import logo from './wb-logo.svg'
const configHeder = {
	logo: logo,
	logoText: 'WBProStat',
	nav: {
		'Просмотр статистики': '/stat',
		'Загрузка данных': '/upload',
		'Настройки': '/conf',
		// '': '',
		// '': '',
		// '': '',
	}
}
class Header extends React.Component {
	render() {
		return (
			<div className="Header">
				<header className="app-header fixed-top">
					<Inner />
					<Side config={configHeder} />
				</header>
			</div>
		);
	}
}

export default Header;
