import React from 'react';
class HomeNavItem extends React.Component {
	render() {
		const nav = this.props.nav;

		return (
			<div className="col-6 col-lg-3" >
				<div className="app-card app-card-stat shadow-sm h-100">
					<div className="app-card-body p-3 p-lg-4">
						<h4 className="stats-type mb-1">{nav.title}</h4>
						<div className="stats-figure">{nav.value}</div>
						<div className="stats-meta">
							{nav.desk}
						</div>
					</div>
					{/*//app-card-body*/}
					<a className="app-card-link-mask" href={nav.path} />
				</div>
				{/*//app-card*/}
			</div>
		);
	}
}
export default HomeNavItem;
