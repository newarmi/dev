import React from 'react';

import { NavLink, Link } from 'react-router-dom';


class Side extends React.Component {
	render() {
		const nav = this.props.nav;
		return (
			<div id="app-sidepanel" className="app-sidepanel">
				<div id="sidepanel-drop" className="sidepanel-drop" />
				<div className="sidepanel-inner d-flex flex-column">
					<button id="sidepanel-close" className="sidepanel-close d-xl-none">×</button>
					<div className="app-branding">
						<Link className="app-logo" to="/"><img className="logo-icon mr-2" src="assets/images/app-logo.svg" alt="logo" /><span className="logo-text">PORTAL</span></Link>
					</div>
					{/*//app-branding*/}
					<nav id="app-nav-main" className="app-nav app-nav-main flex-grow-1">
						<ul className="app-menu list-unstyled accordion" id="menu-accordion">
							{Object.keys(nav).map(elem => {
								return (
									<li key={nav[elem].path} className="nav-item">
										{/* Navitem */}
										<NavLink exact className="nav-link" to={nav[elem].path}>
											<span className="nav-icon">
												{nav[elem].img}
											</span>
											<span className="nav-link-text">{elem}</span>
										</NavLink>

									</li>
								);
							})}

							{/*//nav-item*/}
						</ul>
						{/*//app-menu*/}
					</nav>
					{/*//app-nav*/}
				</div>
				{/*//sidepanel-inner*/}
			</div>

		);

	}
}
export default Side;