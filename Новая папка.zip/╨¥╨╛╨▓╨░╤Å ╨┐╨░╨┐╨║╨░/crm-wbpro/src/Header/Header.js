import React from 'react';
import Top from './Top/Top';
import Side from './Side/Side';

class Header extends React.Component {

	render() {
		return (
			<header className="app-header fixed-top">
				<Top />
				<Side nav={this.props.config} />
			</header>
		);
	}
}
export default Header;