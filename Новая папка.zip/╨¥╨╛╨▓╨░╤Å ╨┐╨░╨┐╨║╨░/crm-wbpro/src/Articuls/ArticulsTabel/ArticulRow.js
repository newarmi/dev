import React from 'react';
class ArticulRow extends React.Component {
	flag = (bool, val) => {
		if (bool) {
			return (
				<span className="text-success">
					<svg width="1em" height="1em" viewBox="0 0 16 16" className="bi bi-arrow-up" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
						<path fillRule="evenodd" d="M8 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L7.5 2.707V14.5a.5.5 0 0 0 .5.5z" />
					</svg>
					{val}%
				</span>
			)
		} else {
			return (
				<span className="text-danger">
					<svg width="1em" height="1em" viewBox="0 0 16 16" className="bi bi-arrow-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
						<path fillRule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z" />
					</svg>
					{val}%
				</span>
			)
		}
	}
	render() {
		const info = this.props.info;
		return (
			<tr>
				<td className="cell">{info.articul}</td>
				<td className="cell">{
					info.key.map((elem, i) => {
						return (<span key={'keysRowId' + i} className="truncate">{elem};&emsp;</span>
						)
					})
				}
				</td>
				<td className="cell"><span>17 Oct</span><span className="note">2:16 PM</span></td>
				<td className="cell">{this.flag(info.ret.flag, info.ret.proth)}</td>
				<td className="cell"><a className="btn-sm app-btn-secondary" href={`articul/${info.articul}`}>View</a></td>
			</tr>
		);
	}
}
export default ArticulRow;