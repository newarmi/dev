
import React from 'react';
import ArticulRow from './ArticulRow';
class ArticulTabel extends React.Component {

	render() {
		const list = this.props.listArt
		console.log(list);

		return (
			<table className="table app-table-hover mb-0 text-left">
				<thead>
					<tr>
						<th className="cell">Артикул</th>
						<th className="cell">Ключи</th>
						<th className="cell">Дата</th>
						<th className="cell">Рейтинг</th>
						<th className="cell"></th>
					</tr>
				</thead>
				<tbody>
					{
						list.map((elem, i) => {
							return (
								<ArticulRow key={'artItemId' + i} info={elem} />
							);
						})
					}
				</tbody>
			</table>
		);
	}
}
export default ArticulTabel;