import React from "react";
import AddProduct from "./AddProduct/AddProduct";
class Settings extends React.Component {
	render() {
		return (
			<div className="app-content pt-3 p-md-3 p-lg-4">
				<div className="container-xl">
					<h1 className="app-page-title">Настройки</h1>
					<hr className="mb-4" />
					<AddProduct />
					<hr className="my-4" />
					<div className="row g-4 settings-section">
						<div className="col-12 col-md-4">
							<h3 className="section-title">Plan</h3>
							<div className="section-intro">Settings section intro goes here. Lorem ipsum dolor sit amet, consectetur
								adipiscing elit. <a href="help.html">Learn more</a></div>
						</div>
						<div className="col-12 col-md-8">
							<div className="app-card app-card-settings shadow-sm p-4">
								<div className="app-card-body">
									<div className="mb-2"><strong>Current Plan:</strong> Pro</div>
									<div className="mb-2"><strong>Status:</strong> <span className="badge bg-success">Active</span></div>
									<div className="mb-2"><strong>Expires:</strong> 2030-09-24</div>
									<div className="mb-4"><strong>Invoices:</strong> <a href="#">view</a></div>
									<div className="row justify-content-between">
										<div className="col-auto">
											<a className="btn app-btn-primary" href="#">Upgrade Plan</a>
										</div>
										<div className="col-auto">
											<a className="btn app-btn-secondary" href="#">Cancel Plan</a>
										</div>
									</div>
								</div>
								{/*//app-card-body*/}
							</div>
							{/*//app-card*/}
						</div>
					</div>
					{/*//row*/}
					<hr className="my-4" />

				</div>
				{/*//container-fluid*/}
			</div>

		);
	}
}
export default Settings