import React from "react";
class AddProduct extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			articul: '',
			keys: [''],
			maxKey: 3,
		}
	}
	chengeArticul = (e) => {
		this.setState({ articul: e.target.value })
	}
	chengeKey = (i, e) => {
		let newValue = this.state.keys[i];
		newValue = e.target.value;
		let newMas = this.state.keys;
		newMas[i] = newValue;

		this.setState({ keys: newMas })


	}
	submit = (e) => {
		e.preventDefault()


	}
	addKey = () => {
		if (this.state.keys.length < this.state.maxKey) {
			let newMas = this.state.keys;
			newMas.push('');

			this.setState({ keys: newMas });
		}
	}
	removeKey = (index) => {
		let newMas = this.state.keys.filter((elem, i) => {
			if (i != index) {
				return true;
			} else {
				return false;
			}
		})
		this.setState({ keys: newMas });


	}
	render() {
		let inputs = this.state;
		return (
			<div className="row g-4 settings-section">
				<div className="col-12 col-md-4">
					<h3 className="section-title">Добавить товар</h3>
					<div className="section-intro"><p>Вы можете добавть еще 5 товаров и 3 ключа к каждому</p>
						<a className="btn app-btn-primary mb-2" href="">Рассширить слежку</a></div>
				</div>
				<div className="col-12 col-md-8">
					<div className="app-card app-card-settings shadow-sm p-4">
						<div className="app-card-body">
							<form className="settings-form" onSubmit={this.submit}>

								<div className="mb-3">
									<label htmlFor="setting-input-1" className="form-label">Артикул<span className="ml-2" data-container="body" data-toggle="popover" data-trigger="hover" data-placement="top" data-content="This is a Bootstrap popover example. You can use popover to provide extra info."><svg width="1em" height="1em" viewBox="0 0 16 16" className="bi bi-info-circle" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
										<path fillRule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
										<path d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588z" />
										<circle cx={8} cy="4.5" r={1} />
									</svg></span></label>
									<input type="number" className="form-control" id="setting-input-1" onChange={this.chengeArticul} placeholder="123456" required />
								</div>

								{inputs.keys.map((elem, i) => {
									return (
										<div className="KeyElem" key={i}>
											<label htmlFor="setting-input-2" className="form-label">Ключ</label>
											<div className="mb-3 d-flex" >
												<input onChange={(e) => { this.chengeKey(i, e) }} type="text" className="form-control" id="setting-input-2" placeholder="Вибро Яйцо" value={elem} required />
												<button type="button" className="btn btn-danger ml-2"
													onClick={
														() => {
															this.removeKey(i);
														}
													}>-</button>
											</div>
										</div>
									);
								})
								}

								<button type="button" className="btn btn-success mr-2" onClick={this.addKey}>+</button>
								<button type="submit" className="btn app-btn-primary" >Save Changes</button>
							</form>
						</div>
						{/*//app-card-body*/}
					</div>
					{/*//app-card*/}
				</div>
			</div >
		);
	}
}
export default AddProduct